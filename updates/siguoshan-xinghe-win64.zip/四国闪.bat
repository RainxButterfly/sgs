@echo off
start "" "%~dp0sanguosha.exe"
