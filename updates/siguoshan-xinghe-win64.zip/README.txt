四国闪 · 星河 v0.9.3

作者：星河一叶Roxy
维护邮箱：ck_xuv@vip.qq.com

解压后双击 四国闪.bat 启动（也可以直接运行 sanguosha.exe）。
首次创建房间若出现 Windows 防火墙提示，请允许专用网络访问。
手机与电脑连接同一 WiFi 后，可扫描大厅二维码加入。
